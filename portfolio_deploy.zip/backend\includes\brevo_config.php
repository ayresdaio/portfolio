<?php
/**
 * =====================================================================
 * CONFIGURAÇÃO ISOLADA DO SMTP DO BREVO (EX-SENDINBLUE)
 * =====================================================================
 * Este ficheiro define as constantes de configuração do SMTP do Brevo
 * para o envio de emails transacionais (recuperação de senha, contacto).
 */

// --- Configurações de E-mail (Brevo) ---
define('SMTP_HOST', ($_ENV['BREVO_SMTP_HOST'] ?? $_SERVER['BREVO_SMTP_HOST'] ?? getenv('BREVO_SMTP_HOST')) ?: 'smtp-relay.brevo.com');
define('SMTP_PORT', ($_ENV['BREVO_SMTP_PORT'] ?? $_SERVER['BREVO_SMTP_PORT'] ?? getenv('BREVO_SMTP_PORT')) ?: 587);
define('SMTP_USER', ($_ENV['BREVO_SMTP_USER'] ?? $_SERVER['BREVO_SMTP_USER'] ?? getenv('BREVO_SMTP_USER')) ?: '');
define('SMTP_PASS', ($_ENV['BREVO_SMTP_PASS'] ?? $_SERVER['BREVO_SMTP_PASS'] ?? getenv('BREVO_SMTP_PASS')) ?: '');
define('EMAIL_REMETENTE', ($_ENV['ADMIN_EMAIL'] ?? $_SERVER['ADMIN_EMAIL'] ?? getenv('ADMIN_EMAIL')) ?: 'ayresdaioneto@gmail.com');
define('NOME_REMETENTE', 'Portfólio Ayres');

// ID da lista da Newsletter na sua consola Brevo (por defeito 2)
define('BREVO_LIST_ID', 2);

?>
