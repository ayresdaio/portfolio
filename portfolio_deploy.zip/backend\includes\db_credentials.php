<?php
/**
 * =====================================================================
 * CREDENCIAIS DA BASE DE DADOS (Substituto Seguro do .env)
 * =====================================================================
 * Preencha aqui os dados da sua base de dados do InfinityFree.
 * O InfinityFree pode bloquear a leitura do ficheiro .env. 
 * Este ficheiro contorna esse problema.
 * O ficheiro está protegido pelo .htaccess e não pode ser acedido via browser.
 */

// NOTA: PREENCHA COM AS SUAS INFORMAÇÕES ANTES DE ENVIAR PARA O SERVIDOR!

$_ENV['DB_HOST'] = 'localhost';          // Host do banco de dados na VPS
$_ENV['DB_NAME'] = 'ayre_port';          // Nome da base de dados configurada na VPS
$_ENV['DB_USER'] = 'ayre_ayresdaioport';  // Utilizador da base de dados na VPS
$_ENV['DB_PASS'] = 'ivaport_ayres*#';     // Palavra-passe do utilizador na VPS
$_ENV['ENVIRONMENT'] = 'production';      // Ambiente definido como produção para desativar exibição de erros no output

// Credenciais do Servidor de Email (SMTP para notificações)
$_ENV['SMTP_HOST'] = 'smtp.gmail.com';
$_ENV['SMTP_USER'] = 'seu_email@gmail.com';
$_ENV['SMTP_PASS'] = 'sua_app_password';
$_ENV['SMTP_PORT'] = '587';
$_ENV['ADMIN_EMAIL'] = 'ayresdaioneto@gmail.com'; // Email do administrador para recepção de mensagens

// Carrega também para o $_SERVER para máxima compatibilidade
foreach ($_ENV as $key => $value) {
    $_SERVER[$key] = $value;
}
